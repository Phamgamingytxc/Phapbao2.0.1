package vn.phapbao.vip;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Quality;
import vn.phapbao.vip.Model.Tier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class Commands implements TabExecutor {
    private static final List<String> PLAYER_SUBS = List.of("menu", "info", "luyenhoa", "giaitru", "nangcap", "daily", "list", "kho", "skills", "skill", "info");
    private static final List<String> ADMIN_SUBS = List.of("give", "resetslot", "reload");

    private final PhapBaoVIP plugin;

    public Commands(PhapBaoVIP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length == 0 ? "menu" : args[0].toLowerCase(Locale.ROOT);

        // Lenh admin (co the dung o console)
        switch (sub) {
            case "give" -> {
                if (!admin(sender)) return true;
                give(sender, args);
                return true;
            }
            case "resetslot" -> {
                if (!admin(sender)) return true;
                if (args.length < 2) {
                    plugin.send(sender, "&cDùng: /pb resetslot <người chơi>");
                    return true;
                }
                @SuppressWarnings("deprecation")
                org.bukkit.OfflinePlayer off = Bukkit.getOfflinePlayer(args[1]);
                plugin.players().setBound(off.getUniqueId(), 0);
                plugin.send(sender, "&aĐã đặt lại số ô bản mệnh của &f" + args[1] + "&a về 0.");
                return true;
            }
            case "reload" -> {
                if (!admin(sender)) return true;
                plugin.reload();
                plugin.send(sender, "&aĐã tải lại cấu hình.");
                return true;
            }
            default -> { /* lenh nguoi choi o duoi */ }
        }

        if (!(sender instanceof Player p)) {
            plugin.send(sender, "&cLệnh này chỉ dùng trong game.");
            return true;
        }
        switch (sub) {
            case "menu" -> plugin.menus().openMain(p);
            case "luyenhoa", "bind" -> plugin.actions().bind(p);
            case "giaitru", "unbind" -> plugin.actions().unbind(p);
            case "nangcap", "upgrade" -> plugin.actions().upgrade(p);
            case "daily" -> plugin.actions().daily(p);
            case "list", "kho" -> plugin.menus().openCatalog(p);
            case "skills", "skill" -> plugin.menus().openSkills(p);
            case "info" -> { info(p); plugin.menus().openDetail(p); }
            default -> plugin.send(p, "&cLệnh không tồn tại. Dùng &e/pb &cđể mở menu.");
        }
        return true;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("phapbao.admin")) return true;
        plugin.send(s, "&cNgươi không có quyền.");
        return false;
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 3) {
            plugin.send(sender, "&cDùng: /pb give <người chơi> <id> [cấp]");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            plugin.send(sender, "&cNgười chơi không online.");
            return;
        }
        PhapBao def = plugin.defs().get(args[2]);
        if (def == null) {
            plugin.send(sender, "&cKhông có pháp bảo id &f" + args[2] + "&c. Xem danh sách bằng Tab.");
            return;
        }
        int level = 0;
        if (args.length >= 4) {
            try {
                level = Math.max(0, Math.min(plugin.getConfig().getInt("settings.max-level", 10), Integer.parseInt(args[3])));
            } catch (NumberFormatException e) {
                plugin.send(sender, "&cCấp phải là số.");
                return;
            }
        }
        ItemStack it = plugin.items().create(def, level);
        plugin.actions().give(target, it);
        plugin.send(sender, "&aĐã trao &f" + def.name() + " &e+" + level + " &acho &f" + target.getName() + "&a.");
        if (!sender.equals(target)) plugin.send(target, "&aNgươi nhận được &f" + def.name() + "&a!");
    }

    private void info(Player p) {
        ItemStack it = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(it);
        if (def == null) {
            plugin.send(p, "&cHãy cầm pháp bảo trên tay.");
            return;
        }
        Quality q = plugin.defs().quality(def.quality());
        UUID owner = plugin.items().owner(it);
        Tier t = plugin.defs().tierOf(p);
        plugin.send(p, "&f" + def.name() + " &7| Phẩm cấp: " + (q == null ? def.quality() : q.color() + q.name())
                + " &7| Cấp: &e+" + plugin.items().level(it)
                + " &7| " + (owner == null ? "&cChưa luyện hóa" : owner.equals(p.getUniqueId()) ? "&aCủa ngươi" : "&cCó chủ khác"));
        plugin.send(p, "&7Linh lực: &b" + Msg.fmt(plugin.players().mana(p)) + "&7/&b" + Msg.fmt(plugin.players().maxMana(p))
                + " &7| VIP: " + t.display());
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean isAdmin = sender.hasPermission("phapbao.admin");
        if (args.length == 1) {
            List<String> all = new ArrayList<>(PLAYER_SUBS);
            if (isAdmin) all.addAll(ADMIN_SUBS);
            for (String s : all) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (isAdmin && args.length == 2 && (args[0].equalsIgnoreCase("give") || args[0].equalsIgnoreCase("resetslot"))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
            }
        } else if (isAdmin && args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (PhapBao d : plugin.defs().all()) {
                if (d.id().startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(d.id());
            }
        }
        return out;
    }
}
