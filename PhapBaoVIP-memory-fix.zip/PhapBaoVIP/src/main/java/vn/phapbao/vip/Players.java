package vn.phapbao.vip;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import vn.phapbao.vip.Model.Tier;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Trang thai nguoi choi: linh luc, hoi chieu, so slot ban menh, qua hang ngay, canh gioi. */
public final class Players {
    private final PhapBaoVIP plugin;
    private final Map<UUID, Double> mana = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final File file;
    private final YamlConfiguration data;
    private boolean warnedPapi;

    public Players(PhapBaoVIP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        this.data = YamlConfiguration.loadConfiguration(file);
    }

    // ---------- Canh gioi (doc qua PlaceholderAPI bang reflection) ----------

    public int realm(Player p) {
        String ph = plugin.getConfig().getString("realm.placeholder", "");
        if (ph == null || ph.isBlank()) return 0;
        if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            if (!warnedPapi) {
                warnedPapi = true;
                plugin.getLogger().warning("realm.placeholder duoc cau hinh nhung khong co PlaceholderAPI, bo qua canh gioi.");
            }
            return 0;
        }
        try {
            Class<?> c = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
            Object r = c.getMethod("setPlaceholders", Player.class, String.class).invoke(null, p, ph);
            String s = String.valueOf(r);
            if (s.equals(ph)) return 0; // placeholder chua duoc phan giai
            String digits = s.replaceAll("[^0-9]", "");
            if (digits.isEmpty()) return 0;
            return Math.min(Integer.parseInt(digits), 10000);
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------- Linh luc ----------

    public double maxMana(Player p) {
        var cfg = plugin.getConfig();
        Tier t = plugin.defs().tierOf(p);
        return cfg.getDouble("mana.base", 100)
                + realm(p) * cfg.getDouble("realm.mana-per-realm", 20)
                + t.manaBonus();
    }

    public double mana(Player p) {
        return mana.computeIfAbsent(p.getUniqueId(), k -> maxMana(p));
    }

    public boolean spend(Player p, double amount) {
        double cur = mana(p);
        if (cur < amount) return false;
        mana.put(p.getUniqueId(), cur - amount);
        return true;
    }

    /** Chay moi giay: hoi linh luc. */
    public void tick() {
        double base = plugin.getConfig().getDouble("mana.regen-per-second", 4);
        for (Player p : Bukkit.getOnlinePlayers()) {
            double max = maxMana(p);
            double cur = mana.getOrDefault(p.getUniqueId(), max);
            cur = Math.min(max, cur + base * plugin.defs().tierOf(p).regenMultiplier());
            mana.put(p.getUniqueId(), cur);
        }
        mana.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
        cooldowns.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    // ---------- Hoi chieu ----------

    public long cooldownLeftMs(Player p, String key) {
        Map<String, Long> m = cooldowns.get(p.getUniqueId());
        if (m == null) return 0;
        Long until = m.get(key);
        if (until == null) return 0;
        return Math.max(0, until - System.currentTimeMillis());
    }

    public void setCooldown(Player p, String key, long ms) {
        cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(key, System.currentTimeMillis() + ms);
    }

    // ---------- Du lieu luu ----------

    public int bound(UUID id) {
        return data.getInt("players." + id + ".bound", 0);
    }

    public void addBound(UUID id, int delta) {
        data.set("players." + id + ".bound", Math.max(0, bound(id) + delta));
        save();
    }

    public void setBound(UUID id, int value) {
        data.set("players." + id + ".bound", Math.max(0, value));
        save();
    }

    public String lastDaily(UUID id) {
        return data.getString("players." + id + ".daily", "");
    }

    public void setDaily(UUID id, String date) {
        data.set("players." + id + ".daily", date);
        save();
    }

    public void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Khong luu duoc data.yml: " + e.getMessage());
        }
    }
}
