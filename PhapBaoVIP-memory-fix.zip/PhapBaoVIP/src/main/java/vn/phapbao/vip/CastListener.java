package vn.phapbao.vip;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Skill;
import vn.phapbao.vip.Model.Tier;

import java.util.UUID;

/** Chuot phai = chieu 1, Shift + chuot phai = chieu 2. */
public final class CastListener implements Listener {
    private final PhapBaoVIP plugin;

    public CastListener(PhapBaoVIP plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        PhapBao def = plugin.items().read(it);
        if (def == null) return;

        // De nguoi choi van mo ruong, bam nut... khi cam kiem (tru khi dang Shift).
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK && !p.isSneaking()
                && e.getClickedBlock() != null && e.getClickedBlock().getType().isInteractable()) {
            return;
        }
        e.setCancelled(true);

        UUID owner = plugin.items().owner(it);
        if (owner == null) {
            plugin.actionBar(p, "&cPháp bảo chưa luyện hóa! Dùng &e/pb luyenhoa");
            return;
        }
        if (!owner.equals(p.getUniqueId())) {
            plugin.actionBar(p, "&cPháp bảo này đã nhận chủ khác, ngươi không điều khiển được.");
            return;
        }
        Tier tier = plugin.defs().tierOf(p);
        if (def.vipOnly() && !tier.vip()) {
            plugin.actionBar(p, "&6Pháp bảo này chỉ dành cho VIP.");
            return;
        }
        int realm = plugin.players().realm(p);
        if (realm < def.minRealm()) {
            plugin.actionBar(p, "&cCảnh giới chưa đủ (cần " + def.minRealm() + ").");
            return;
        }

        boolean second = p.isSneaking() && def.skill2() != null;
        Skill skill = second ? def.skill2() : def.skill1();
        String key = def.id() + ":" + (second ? 2 : 1);

        long left = plugin.players().cooldownLeftMs(p, key);
        if (left > 0) {
            plugin.actionBar(p, "&7" + skill.name() + " &chồi chiêu: &f" + Msg.fmt(Math.ceil(left / 100.0) / 10.0) + "s");
            return;
        }
        if (!plugin.players().spend(p, skill.mana())) {
            plugin.actionBar(p, "&cKhông đủ linh lực! &7(" + Msg.fmt(plugin.players().mana(p)) + "/"
                    + Msg.fmt(plugin.players().maxMana(p)) + ")");
            return;
        }
        double cd = skill.cooldown() * (1.0 - Math.min(80, tier.cooldownReduction()) / 100.0);
        plugin.players().setCooldown(p, key, (long) (cd * 1000));

        var cfg = plugin.getConfig();
        int level = plugin.items().level(it);
        // Damage skill được scale theo phẩm cấp pháp bảo. Damage trong config chỉ còn
        // là tham số phụ; mốc thấp nhất luôn là 100 để tránh skill yếu bất thường.
        var quality = plugin.defs().quality(def.quality());
        double qualityBase = quality != null ? quality.skillDamageBase() : 100.0;
        double dmg = Math.max(100.0, qualityBase)
                * (1.0 + level * cfg.getDouble("settings.level-damage-scale", 0.10))
                * (1.0 + realm * cfg.getDouble("settings.realm-damage-scale", 0.03))
                * Math.max(0.25, skill.damageMultiplier());

        plugin.engine().cast(p, skill, dmg);
        plugin.actionBar(p, "&b" + skill.name() + " &8| &9Linh lực: &f" + Msg.fmt(plugin.players().mana(p)) + "/"
                + Msg.fmt(plugin.players().maxMana(p)));
    }
}
