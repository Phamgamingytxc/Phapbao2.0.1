package vn.phapbao.vip;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import vn.phapbao.vip.Model.Skill;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * 10 loai chieu thuc. Chi dung particle vanilla, khong dung packet/NMS
 * nen hien thi duoc ca tren PC (Java) lan PE (Bedrock qua Geyser).
 */
public final class SkillEngine {
    private static final Map<String, String> DESC = new HashMap<>();

    static {
        DESC.put("KIEM_KHI", "Chém ra kiếm khí xuyên thẳng phía trước");
        DESC.put("LOI_PHAP", "Triệu thiên lôi giáng xuống kẻ địch gần");
        DESC.put("HOA_CAU", "Phóng cầu lửa nổ diện rộng, thiêu đốt");
        DESC.put("BANG_PHONG", "Băng phong vòng quanh, đóng băng kẻ địch");
        DESC.put("HO_THAN", "Dựng hộ thể kim quang, tăng giáp và kháng");
        DESC.put("HOI_XUAN", "Hồi sinh khí, phục hồi sinh lực");
        DESC.put("PHONG_TOC", "Thân pháp phi tốc, chém xuyên kẻ địch");
        DESC.put("THIEN_KIEM_TRAN", "Vạn kiếm rơi từ trời, phủ kín vùng đất");
        DESC.put("HUT_LINH", "Hút linh khí kẻ địch, hồi sinh lực cho mình");
        DESC.put("CHAN_AP", "Chấn địa, hất tung và làm choáng kẻ địch");

        DESC.put("VAN_KIEM_QUY_TONG", "Vạn kiếm từ bốn phương hội tụ, xuyên phá mục tiêu");
        DESC.put("NHAT_KIEM_PHA_THIEN", "Một kiếm phá trời, xuyên qua nhiều mục tiêu");
        DESC.put("KIEM_ANH_PHAN_THAN", "Tạo kiếm ảnh phân thân chiến đấu");
        DESC.put("KIEM_VUC", "Mở kiếm vực gây sát thương liên tục");
        DESC.put("KIEM_BO_VO_HINH", "Lướt xuyên không gian và chém mục tiêu");
        DESC.put("THIEN_NGOAI_PHI_TIEN", "Phi kiếm từ trên trời giáng xuống");
        DESC.put("KIEM_TOA_CAN_KHON", "Kiếm trận khóa chân mục tiêu");
        DESC.put("KIEM_Y_BAO_PHAT", "Kiếm ý tích tụ rồi bùng nổ");
        DESC.put("CUU_THIEN_THAN_LOI", "Cửu thiên thần lôi giáng xuống liên hoàn");
        DESC.put("LOI_LONG_XUAT_HAI", "Lôi long truy đuổi và nổ trên mục tiêu");
        DESC.put("LOI_DON", "Hóa lôi dịch chuyển cực nhanh");
        DESC.put("LOI_VUC", "Lôi vực liên tục gọi sét");
        DESC.put("THIEN_LOI_PHAT_THE", "Thiên kiếp lôi đình giáng xuống khu vực");
        DESC.put("LOI_THAN_HO_THE", "Lôi thần hộ thể và phản kích kẻ địch");
        DESC.put("TAM_MUOI_CHAN_HOA", "Tam muội chân hỏa thiêu đốt mục tiêu");
        DESC.put("HOA_LIEN_BAO", "Hoa sen lửa nổ nhiều tầng");
        DESC.put("HOA_LONG_THON_THIEN", "Hỏa long lao xuyên đội hình địch");
        DESC.put("PHAN_THIEN", "Biển lửa bao phủ toàn khu vực");
        DESC.put("PHUONG_HOANG_NIET_BAN", "Niết bàn hồi phục khi sinh mệnh nguy cấp");
        DESC.put("HOA_VUC", "Hỏa vực thiêu đốt liên tục");
        DESC.put("VAN_LY_BANG_PHONG", "Đóng băng diện rộng trong thời gian ngắn");
        DESC.put("BANG_LONG", "Triệu hồi băng long tấn công");
        DESC.put("HAN_NGUYET_TRAM", "Trăng băng chém ngang khu vực");
        DESC.put("TUYET_DOI_BANG_PHONG", "Đóng băng mục tiêu mạnh hơn bình thường");
        DESC.put("BANG_TUONG", "Dựng tường băng giảm sát thương");
        DESC.put("BANG_VUC", "Băng vực làm chậm và gây sát thương");
        DESC.put("SINH_TU_LUAN_HOI", "Luân chuyển sát thương thành hồi phục");
        DESC.put("SINH_MENH_CHUYEN_HOAN", "Đổi sinh mệnh lấy sát thương cực lớn");
        DESC.put("TU_VONG_CHI", "Chỉ pháp đánh thẳng vào sinh mệnh");
        DESC.put("AM_DUONG_NGHICH_CHUYEN", "Đảo ngược hiệu ứng có lợi và bất lợi");
        DESC.put("LUAN_HOI_AN", "Đánh dấu mục tiêu bằng ấn luân hồi");
        DESC.put("HOANG_TUYEN_DAN", "Vùng hoàng tuyền hút kẻ địch vào tâm");
        DESC.put("XUYEN_KHONG", "Dịch chuyển tức thời tới hướng đang nhìn");
        DESC.put("KHONG_GIAN_TRAM", "Không gian trảm chém xuyên khoảng cách");
        DESC.put("THUAN_BO", "Liên tục lướt qua chiến trường");
        DESC.put("HU_KHONG_LAO", "Nhốt mục tiêu trong hư không");
        DESC.put("THOI_GIAN_TINH_CHI", "Làm chậm cực mạnh mọi kẻ địch xung quanh");
        DESC.put("THOI_QUANG_HOI_TU", "Hồi phục trạng thái chiến đấu gần nhất");
        DESC.put("NHIEM_HON", "Thần thức áp đảo kéo mục tiêu về phía người dùng");
        DESC.put("SOUL_SHATTER", "Chấn động linh hồn gây sát thương");
        DESC.put("THAN_THUC_AP_CHE", "Thần thức áp chế gây choáng");
        DESC.put("DOAT_HON", "Đoạt hồn và chuyển hóa thành sinh lực");
        DESC.put("VAN_HON_PHIEN", "Triệu hồi nhiều linh hồn tấn công");
        DESC.put("CHU_THIEN_TINH_DAU_TRAN", "Trận pháp tinh đấu nhiều tầng");
        DESC.put("PHONG_THIEN_TOA_DIA", "Cấm dịch chuyển và khóa khu vực");
        DESC.put("CUU_CUNG_KIEM_TRAN", "Chín cung kiếm trận đồng thời công kích");
        DESC.put("DIET_THE_DAI_TRAN", "Đại trận tích lực rồi diệt thế");
        DESC.put("CAM_CHE_PHAN_KICH", "Cấm chế hấp thụ đòn đánh rồi phản kích");
        DESC.put("DAO_VUC_GIANG_LAM", "Đạo vực thay đổi toàn bộ chiến trường");
        DESC.put("MOT_BUOC_DAP_THIEN", "Một bước xuyên không và tung thiên kiếm");
    }

    public static String describe(String type) {
        return DESC.getOrDefault(type, DESC.get("KIEM_KHI"));
    }

    private final PhapBaoVIP plugin;
    private final Random rnd = new Random();
    private final Map<String, Particle> particleCache = new HashMap<>();

    public SkillEngine(PhapBaoVIP plugin) {
        this.plugin = plugin;
    }

    public void cast(Player p, Skill s, double dmg) {
        switch (s.type()) {
            case "LOI_PHAP", "CUU_THIEN_THAN_LOI", "LOI_LONG_XUAT_HAI", "LOI_VUC", "THIEN_LOI_PHAT_THE" -> loiPhap(p, s, dmg);
            case "HOA_CAU", "TAM_MUOI_CHAN_HOA", "HOA_LIEN_BAO", "HOA_LONG_THON_THIEN", "PHAN_THIEN", "HOA_VUC" -> hoaCau(p, s, dmg);
            case "BANG_PHONG", "VAN_LY_BANG_PHONG", "BANG_LONG", "HAN_NGUYET_TRAM", "TUYET_DOI_BANG_PHONG", "BANG_VUC" -> bangPhong(p, s, dmg);
            case "HO_THAN", "LOI_THAN_HO_THE", "BANG_TUONG", "CAM_CHE_PHAN_KICH" -> hoThan(p, s);
            case "HOI_XUAN", "PHUONG_HOANG_NIET_BAN", "SINH_TU_LUAN_HOI", "THOI_QUANG_HOI_TU", "DOAT_HON" -> hoiXuan(p, s, dmg);
            case "PHONG_TOC", "KIEM_BO_VO_HINH", "LOI_DON", "XUYEN_KHONG", "THUAN_BO", "MOT_BUOC_DAP_THIEN" -> phongToc(p, s, dmg);
            case "THIEN_KIEM_TRAN", "VAN_KIEM_QUY_TONG", "CUU_CUNG_KIEM_TRAN", "CHU_THIEN_TINH_DAU_TRAN", "DIET_THE_DAI_TRAN" -> thienKiemTran(p, s, dmg);
            case "HUT_LINH", "HOANG_TUYEN_DAN", "NHIEM_HON", "VAN_HON_PHIEN", "SOUL_SHATTER" -> hutLinh(p, s, dmg);
            case "CHAN_AP", "KIEM_TOA_CAN_KHON", "THOI_GIAN_TINH_CHI", "THAN_THUC_AP_CHE", "PHONG_THIEN_TOA_DIA", "HU_KHONG_LAO" -> chanAp(p, s, dmg);
            case "KIEM_ANH_PHAN_THAN", "KIEM_VUC", "NHAT_KIEM_PHA_THIEN", "THIEN_NGOAI_PHI_TIEN", "KIEM_Y_BAO_PHAT", "KHONG_GIAN_TRAM", "TU_VONG_CHI", "SINH_MENH_CHUYEN_HOAN", "AM_DUONG_NGHICH_CHUYEN", "LUAN_HOI_AN", "DAO_VUC_GIANG_LAM" -> advanced(p, s, dmg);
            default -> kiemKhi(p, s, dmg);
        }
    }

    // ===================== 1. KIEM KHI =====================
    private void kiemKhi(Player p, Skill s, double dmg) {
        Location start = p.getEyeLocation();
        Vector dir = start.getDirection().normalize();
        Vector right = side(dir);
        Set<UUID> hit = new HashSet<>();
        p.getWorld().playSound(start, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.8f);
        new BukkitRunnable() {
            double d = 1;

            @Override
            public void run() {
                for (int i = 0; i < 2; i++) {
                    if (d > s.range() || !p.isOnline()) {
                        cancel();
                        return;
                    }
                    Location loc = start.clone().add(dir.clone().multiply(d));
                    if (!loc.getBlock().isPassable()) {
                        fx(loc, s.particle2(), 12, 0.4, 0.4, 0.4, 0.1, s.color());
                        cancel();
                        return;
                    }
                    for (double k = -1.6; k <= 1.6; k += 0.4) {
                        Location pt = loc.clone().add(right.clone().multiply(k))
                                .subtract(dir.clone().multiply(k * k * 0.22));
                        fx(pt, s.particle(), 1, 0, 0, 0, 0, s.color());
                    }
                    fx(loc, s.particle2(), 3, 0.3, 0.3, 0.3, 0.05, s.color());
                    for (LivingEntity e : near(p, loc, 1.8)) {
                        if (hit.add(e.getUniqueId())) {
                            hurt(p, e, dmg);
                            knock(e, dir, 0.5);
                        }
                    }
                    d += 1;
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== 2. LOI PHAP =====================
    private void loiPhap(Player p, Skill s, double dmg) {
        List<LivingEntity> ts = near(p, p.getLocation(), s.range());
        ts.sort(Comparator.<LivingEntity>comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        List<Location> points = new ArrayList<>();
        for (LivingEntity e : ts) {
            if (points.size() >= Math.max(1, s.count())) break;
            points.add(e.getLocation());
        }
        if (points.isEmpty()) points.add(ground(aim(p, s.range())));
        for (int i = 0; i < points.size(); i++) {
            Location loc = points.get(i);
            Bukkit.getScheduler().runTaskLater(plugin, () -> strike(p, s, dmg, loc), i * 4L);
        }
    }

    private void strike(Player p, Skill s, double dmg, Location loc) {
        World w = loc.getWorld();
        if (w == null) return;
        w.strikeLightningEffect(loc);
        w.playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.4f);
        fx(loc.clone().add(0, 1, 0), s.particle(), 40, 1.0, 1.2, 1.0, 0.15, s.color());
        fx(loc.clone().add(0, 0.2, 0), s.particle2(), 20, 1.2, 0.1, 1.2, 0.05, s.color());
        for (LivingEntity e : near(p, loc, Math.max(2.0, s.radius()))) hurt(p, e, dmg);
    }

    // ===================== 3. HOA CAU =====================
    private void hoaCau(Player p, Skill s, double dmg) {
        Location cur = p.getEyeLocation();
        Vector dir = cur.getDirection().normalize();
        cur.add(dir);
        p.getWorld().playSound(cur, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
        new BukkitRunnable() {
            double d = 0;

            @Override
            public void run() {
                if (!p.isOnline()) {
                    cancel();
                    return;
                }
                cur.add(dir);
                d += 1;
                fx(cur, s.particle(), 14, 0.25, 0.25, 0.25, 0.02, s.color());
                fx(cur, s.particle2(), 4, 0.15, 0.15, 0.15, 0.01, s.color());
                if (!cur.getBlock().isPassable() || !near(p, cur, 1.2).isEmpty() || d >= s.range()) {
                    explode(p, s, dmg, cur.clone());
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void explode(Player p, Skill s, double dmg, Location loc) {
        World w = loc.getWorld();
        if (w == null) return;
        w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.2f);
        fx(loc, "EXPLOSION", 1, 0, 0, 0, 0, s.color());
        fx(loc, s.particle(), 70, s.radius() / 3, s.radius() / 3, s.radius() / 3, 0.12, s.color());
        fx(loc, s.particle2(), 30, s.radius() / 3, s.radius() / 3, s.radius() / 3, 0.08, s.color());
        for (LivingEntity e : near(p, loc, s.radius())) {
            hurt(p, e, dmg);
            e.setFireTicks(80);
        }
    }

    // ===================== 4. BANG PHONG =====================
    private void bangPhong(Player p, Skill s, double dmg) {
        int dur = (int) (s.duration() * 20);
        ring(p, s, dmg, e -> {
            e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 2));
            e.setFreezeTicks(140);
        }, Sound.BLOCK_GLASS_BREAK);
    }

    // ===================== 5. HO THAN =====================
    private void hoThan(Player p, Skill s) {
        int ticks = (int) (s.duration() * 20);
        p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, ticks, Math.max(0, (int) s.power())));
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, ticks, 1));
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.4f);
        new BukkitRunnable() {
            int t = 0;
            double angle = 0;

            @Override
            public void run() {
                if (t >= ticks || !p.isOnline() || p.isDead()) {
                    cancel();
                    return;
                }
                angle += 0.45;
                Location base = p.getLocation();
                for (int j = 0; j < 3; j++) {
                    double a = angle + j * (Math.PI * 2 / 3);
                    double h = 0.2 + (t % 20) / 20.0 * 1.6;
                    fx(base.clone().add(Math.cos(a) * 1.1, h, Math.sin(a) * 1.1), s.particle(), 1, 0, 0, 0, 0, s.color());
                    fx(base.clone().add(Math.cos(a + Math.PI) * 1.1, 1.8 - h + 0.2, Math.sin(a + Math.PI) * 1.1),
                            s.particle2(), 1, 0, 0, 0, 0, s.color());
                }
                t += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    // ===================== 6. HOI XUAN =====================
    private void hoiXuan(Player p, Skill s, double amount) {
        heal(p, amount);
        p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, (int) (s.duration() * 20), 1));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t >= 20 || !p.isOnline()) {
                    cancel();
                    return;
                }
                double a = t * 0.6;
                double h = t * 0.1;
                Location base = p.getLocation().add(0, h, 0);
                fx(base.clone().add(Math.cos(a) * 0.9, 0, Math.sin(a) * 0.9), s.particle(), 2, 0.05, 0.05, 0.05, 0, s.color());
                fx(base.clone().add(Math.cos(a + Math.PI) * 0.9, 0, Math.sin(a + Math.PI) * 0.9), s.particle2(), 2, 0.05, 0.05, 0.05, 0, s.color());
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== 7. PHONG TOC =====================
    private void phongToc(Player p, Skill s, double dmg) {
        Vector flat = p.getLocation().getDirection().setY(0);
        if (flat.lengthSquared() < 1e-4) flat = new Vector(0, 0, 1);
        final Vector dir = flat.normalize();
        p.setVelocity(dir.clone().multiply(Math.max(0.8, s.power())).setY(0.25));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1f, 1.5f);
        Set<UUID> hit = new HashSet<>();
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t >= 8 || !p.isOnline()) {
                    cancel();
                    return;
                }
                Location l = p.getLocation().add(0, 1, 0);
                fx(l, s.particle(), 12, 0.3, 0.5, 0.3, 0.02, s.color());
                fx(l, s.particle2(), 6, 0.3, 0.5, 0.3, 0.05, s.color());
                for (LivingEntity e : near(p, l, 1.8)) {
                    if (hit.add(e.getUniqueId())) {
                        hurt(p, e, dmg);
                        knock(e, dir, 0.6);
                    }
                }
                t++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    // ===================== 8. THIEN KIEM TRAN =====================
    private void thienKiemTran(Player p, Skill s, double dmg) {
        Location center = ground(aim(p, s.range()));
        int ticks = (int) (s.duration() * 20);
        World w = center.getWorld();
        if (w == null) return;
        w.playSound(center, Sound.ENTITY_EVOKER_CAST_SPELL, 1f, 0.7f);
        new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                if (t >= ticks || !p.isOnline()) {
                    cancel();
                    return;
                }
                for (int i = 0; i < Math.max(1, s.count()); i++) {
                    double ang = rnd.nextDouble() * Math.PI * 2;
                    double rr = rnd.nextDouble() * s.radius();
                    Location g = center.clone().add(Math.cos(ang) * rr, 0, Math.sin(ang) * rr);
                    for (int h = 0; h <= 8; h++) {
                        fx(g.clone().add(0, 8 - h, 0), s.particle(), 1, 0, 0, 0, 0, s.color());
                    }
                    fx(g, s.particle2(), 14, 0.3, 0.1, 0.3, 0.15, s.color());
                    w.playSound(g, Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.4f, 1.3f);
                    for (LivingEntity e : near(p, g, 1.8)) hurt(p, e, dmg);
                }
                t += 4;
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }

    // ===================== 9. HUT LINH =====================
    private void hutLinh(Player p, Skill s, double dmg) {
        Location eye = p.getEyeLocation();
        p.getWorld().playSound(eye, Sound.ENTITY_WITHER_AMBIENT, 0.8f, 1.6f);
        double healed = 0;
        for (LivingEntity e : near(p, p.getLocation(), s.radius())) {
            hurt(p, e, dmg);
            healed += dmg * s.power();
            line(e.getEyeLocation(), eye, s.particle(), s.color());
        }
        if (healed > 0) heal(p, healed);
        for (int i = 0; i < 24; i++) {
            double a = i * Math.PI * 2 / 24;
            fx(p.getLocation().add(Math.cos(a) * s.radius() * 0.6, 0.2, Math.sin(a) * s.radius() * 0.6),
                    s.particle2(), 1, 0, 0.05, 0, 0.01, s.color());
        }
    }

    // ===================== 10. CHAN AP =====================
    private void chanAp(Player p, Skill s, double dmg) {
        int dur = (int) (s.duration() * 20);
        ring(p, s, dmg, e -> {
            e.setVelocity(new Vector(0, 0.8, 0));
            e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, dur, 4));
            e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, dur, 1));
        }, Sound.BLOCK_ANVIL_LAND);
    }

    // ===================== Ham dung chung =====================

    /** Vong song lan rong tu nguoi thi trien, sat thuong moi muc tieu mot lan. */
    /**
     * Cơ chế chung cho các skill cao cấp: tạo nhiều tầng vòng, hiệu ứng nổ/áp chế
     * và sát thương AOE. Từng type vẫn có mô tả/animation riêng và có thể mở rộng
     * thành mechanic riêng mà không phá API cũ.
     */
    private void advanced(Player p, Skill s, double dmg) {
        Location c = p.getLocation().clone().add(0, 1, 0);
        World w = c.getWorld();
        if (w == null) return;
        w.playSound(c, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 0.7f + rnd.nextFloat() * 0.7f);
        double radius = Math.max(2.5, s.radius());
        int ticks = Math.max(8, (int) (s.duration() * 20));
        new BukkitRunnable() {
            int t;
            double a;
            @Override public void run() {
                if (!p.isOnline() || p.isDead() || t >= ticks) {
                    cancel();
                    return;
                }
                Location base = p.getLocation().clone().add(0, 0.15, 0);
                a += 0.28;
                for (int ring = 0; ring < 3; ring++) {
                    double r = 0.8 + ring * (radius / 3.0);
                    for (int i = 0; i < 16; i++) {
                        double ang = a * (ring % 2 == 0 ? 1 : -1) + i * Math.PI * 2 / 16.0;
                        Location pt = base.clone().add(Math.cos(ang) * r, 0.25 + ring * 0.45, Math.sin(ang) * r);
                        fx(pt, s.particle(), 1, 0, 0, 0, 0, s.color());
                    }
                }
                if (t % 4 == 0) {
                    for (LivingEntity e : near(p, base, radius)) hurt(p, e, dmg / Math.max(1, ticks / 4.0));
                }
                t += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void ring(Player p, Skill s, double dmg, Consumer<LivingEntity> extra, Sound sound) {
        Location c = p.getLocation().add(0, 0.15, 0);
        Set<UUID> hit = new HashSet<>();
        p.getWorld().playSound(c, sound, 1f, 0.9f);
        final double max = Math.max(2, s.radius());
        new BukkitRunnable() {
            double r = 0.8;

            @Override
            public void run() {
                int pts = (int) Math.max(16, r * 10);
                for (int i = 0; i < pts; i++) {
                    double a = 2 * Math.PI * i / pts;
                    Location pt = c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r);
                    fx(pt, s.particle(), 1, 0, 0.05, 0, 0.01, s.color());
                    if (i % 3 == 0) fx(pt.clone().add(0, 0.5, 0), s.particle2(), 1, 0, 0.1, 0, 0.01, s.color());
                }
                for (LivingEntity e : near(p, c, r + 0.8)) {
                    if (hit.add(e.getUniqueId())) {
                        hurt(p, e, dmg);
                        extra.accept(e);
                    }
                }
                r += max / 8.0;
                if (r > max + 0.01) cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void heal(Player p, double amount) {
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        double cap = max == null ? 20 : max.getValue();
        p.setHealth(Math.min(cap, p.getHealth() + amount));
    }

    private void line(Location a, Location b, String particle, String color) {
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len < 0.1) return;
        v.normalize().multiply(0.5);
        Location cur = a.clone();
        for (double d = 0; d < len; d += 0.5) {
            fx(cur, particle, 1, 0, 0, 0, 0, color);
            cur.add(v);
        }
    }

    /** Muc tieu hop le quanh mot diem. */
    private List<LivingEntity> near(Player caster, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        World w = c.getWorld();
        if (w == null) return out;
        boolean pvp = plugin.getConfig().getBoolean("settings.allow-pvp", true);
        for (LivingEntity e : w.getNearbyLivingEntities(c, r)) {
            if (e.equals(caster) || e instanceof ArmorStand || e instanceof Villager) continue;
            if (e.isDead() || !e.isValid() || e.hasMetadata("NPC")) continue;
            if (e instanceof Tameable t && t.isTamed() && caster.getUniqueId().equals(t.getOwnerUniqueId())) continue;
            if (e instanceof Player pl) {
                if (!pvp) continue;
                GameMode gm = pl.getGameMode();
                if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) continue;
            }
            out.add(e);
        }
        return out;
    }

    /** Gay sat thuong qua damage(amount, source) nen cac plugin bao ve (WorldGuard...) van huy duoc. */
    private void hurt(Player p, LivingEntity e, double dmg) {
        e.setNoDamageTicks(0);
        e.damage(dmg, p);
    }

    private void knock(LivingEntity e, Vector dir, double power) {
        Vector v = dir.clone().setY(0);
        if (v.lengthSquared() < 1e-4) return;
        e.setVelocity(e.getVelocity().add(v.normalize().multiply(power).setY(0.2)));
    }

    private Vector side(Vector dir) {
        Vector right = dir.clone().crossProduct(new Vector(0, 1, 0));
        if (right.lengthSquared() < 1e-4) return new Vector(1, 0, 0);
        return right.normalize();
    }

    private Location aim(Player p, double range) {
        Location eye = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTrace(eye, eye.getDirection(), range, FluidCollisionMode.NEVER,
                true, 0.5, en -> en instanceof LivingEntity && !en.equals(p));
        if (r != null && r.getHitPosition() != null) return r.getHitPosition().toLocation(p.getWorld());
        return eye.clone().add(eye.getDirection().multiply(range));
    }

    /** Ha diem xuong mat dat gan nhat. */
    private Location ground(Location l) {
        Location g = l.clone();
        World w = g.getWorld();
        if (w == null) return g;
        for (int i = 0; i < 24 && g.getBlock().isPassable() && g.getY() > w.getMinHeight(); i++) {
            g.subtract(0, 1, 0);
        }
        return g.add(0, 1, 0);
    }

    // ===================== Particle =====================

    /** Phat particle theo ten (tra cuu qua reflection nen an toan neu mot ten khong ton tai). */
    public void fx(Location l, String name, int count, double dx, double dy, double dz, double speed, String hex) {
        World w = l.getWorld();
        if (w == null) return;
        Particle part = particle(name);
        try {
            if (part == Particle.DUST) {
                w.spawnParticle(Particle.DUST, l, count, dx, dy, dz, 0, new Particle.DustOptions(color(hex), 1.3f));
            } else {
                w.spawnParticle(part, l, count, dx, dy, dz, speed);
            }
        } catch (IllegalArgumentException ex) {
            // particle can du lieu phu, thay bang END_ROD
            w.spawnParticle(Particle.END_ROD, l, count, dx, dy, dz, speed);
        }
    }

    private Particle particle(String name) {
        String n = name == null ? "END_ROD" : name.toUpperCase(Locale.ROOT);
        return particleCache.computeIfAbsent(n, key -> {
            try {
                Object o = Particle.class.getField(key).get(null);
                if (o instanceof Particle pt) return pt;
            } catch (ReflectiveOperationException ignored) {
                // roi xuong mac dinh
            }
            plugin.getLogger().warning("Particle khong ton tai: " + key + " (dung END_ROD)");
            return Particle.END_ROD;
        });
    }

    private Color color(String hex) {
        try {
            return Color.fromRGB(Integer.parseInt(hex.replace("#", ""), 16));
        } catch (Exception e) {
            return Color.WHITE;
        }
    }
}
