package vn.phapbao.vip;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import vn.phapbao.vip.Model.PhapBao;
import vn.phapbao.vip.Model.Quality;
import vn.phapbao.vip.Model.Skill;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Tao, hien thi (ten/lore/thuoc tinh) va doc du lieu phap bao tu PDC. */
public final class ItemService {
    private final PhapBaoVIP plugin;
    private final Defs defs;
    private final NamespacedKey kId;
    private final NamespacedKey kLevel;
    private final NamespacedKey kOwner;
    private final NamespacedKey kOwnerName;
    private final NamespacedKey kAtk;
    private final NamespacedKey kSpd;

    public ItemService(PhapBaoVIP plugin, Defs defs) {
        this.plugin = plugin;
        this.defs = defs;
        this.kId = new NamespacedKey(plugin, "pb_id");
        this.kLevel = new NamespacedKey(plugin, "pb_level");
        this.kOwner = new NamespacedKey(plugin, "pb_owner");
        this.kOwnerName = new NamespacedKey(plugin, "pb_owner_name");
        this.kAtk = new NamespacedKey(plugin, "pb_attack");
        this.kSpd = new NamespacedKey(plugin, "pb_speed");
    }

    public ItemStack create(PhapBao def, int level) {
        Material m = Material.matchMaterial(def.material());
        if (m == null) m = Material.IRON_SWORD;
        ItemStack it = new ItemStack(m);
        render(it, def, level, null, null);
        return it;
    }

    // ---------- Doc ----------

    public PhapBao read(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        String id = item.getItemMeta().getPersistentDataContainer().get(kId, PersistentDataType.STRING);
        return defs.get(id);
    }

    public int level(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return 0;
        Integer lv = item.getItemMeta().getPersistentDataContainer().get(kLevel, PersistentDataType.INTEGER);
        return lv == null ? 0 : lv;
    }

    public UUID owner(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        String s = item.getItemMeta().getPersistentDataContainer().get(kOwner, PersistentDataType.STRING);
        if (s == null) return null;
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    // ---------- Ghi / hien thi ----------

    /** Ghi lai ten, lore, thuoc tinh va du lieu PDC len vat pham. owner = null nghia la chua luyen hoa. */
    public void render(ItemStack item, PhapBao def, int level, UUID owner, String ownerName) {
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(kId, PersistentDataType.STRING, def.id());
        pdc.set(kLevel, PersistentDataType.INTEGER, level);
        if (owner != null) {
            pdc.set(kOwner, PersistentDataType.STRING, owner.toString());
            pdc.set(kOwnerName, PersistentDataType.STRING, ownerName == null ? "?" : ownerName);
        } else {
            pdc.remove(kOwner);
            pdc.remove(kOwnerName);
        }

        Quality q = defs.quality(def.quality());
        String color = q != null ? q.color() : "&f";
        String qName = q != null ? q.name() : def.quality();
        int max = plugin.getConfig().getInt("settings.max-level", 10);
        double atk = def.attackDamage() + level * plugin.getConfig().getDouble("settings.level-attack-bonus", 0.8);

        meta.displayName(Msg.c(color + "&l" + def.name() + (level > 0 ? " &e+" + level : "")));

        List<String> lines = new ArrayList<>();
        lines.add("&8━━━━━━━━━━━━━━━━━━");
        lines.add("&7Phẩm cấp: " + color + qName);
        lines.add("&7Cấp luyện: &e+" + level + "&7/" + max);
        lines.add("&7Công kích: &c" + Msg.fmt(atk));
        if (owner != null) lines.add("&7Chủ nhân: &a" + ownerName);
        else lines.add("&7Chủ nhân: &cChưa luyện hóa &8(/pb luyenhoa)");
        if (def.vipOnly()) lines.add("&6&l★ Pháp bảo dành riêng cho VIP ★");
        if (def.minRealm() > 0) lines.add("&7Yêu cầu cảnh giới: &b" + def.minRealm());
        lines.add("&8━━━━━━━━━━━━━━━━━━");
        addSkill(lines, "Chuột phải", def.skill1());
        if (def.skill2() != null) addSkill(lines, "Shift + Chuột phải", def.skill2());
        if (!def.lore().isEmpty()) {
            lines.add("&8━━━━━━━━━━━━━━━━━━");
            lines.addAll(def.lore());
        }
        List<Component> lore = new ArrayList<>();
        for (String l : lines) lore.add(Msg.c(l));
        meta.lore(lore);

        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);

        // Dat day du thuoc tinh vi modifier tuy chinh se thay the gia tri mac dinh cua kiem.
        meta.removeAttributeModifier(Attribute.ATTACK_DAMAGE);
        meta.removeAttributeModifier(Attribute.ATTACK_SPEED);
        meta.addAttributeModifier(Attribute.ATTACK_DAMAGE, new AttributeModifier(kAtk, atk - 1.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));
        meta.addAttributeModifier(Attribute.ATTACK_SPEED, new AttributeModifier(kSpd, def.attackSpeed() - 4.0,
                AttributeModifier.Operation.ADD_NUMBER, EquipmentSlotGroup.MAINHAND));

        if (q != null && q.glow()) meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
    }

    private void addSkill(List<String> lines, String key, Skill s) {
        if (s == null) return;
        lines.add("&b▶ " + key + ": &f" + s.name() + " &8(" + Msg.fmt(s.mana()) + " linh lực · "
                + Msg.fmt(s.cooldown()) + "s)");
        lines.add("&7   " + SkillEngine.describe(s.type()));
    }
}
