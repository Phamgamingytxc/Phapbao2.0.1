package vn.phapbao.vip;

import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class PhapBaoVIP extends JavaPlugin {
    private Defs defs;
    private Players players;
    private ItemService items;
    private SkillEngine engine;
    private Actions actions;
    private Menus menus;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        defs = new Defs(this);
        defs.load();
        players = new Players(this);
        items = new ItemService(this, defs);
        engine = new SkillEngine(this);
        actions = new Actions(this);
        menus = new Menus(this);

        PluginCommand cmd = getCommand("phapbao");
        if (cmd != null) {
            Commands ex = new Commands(this);
            cmd.setExecutor(ex);
            cmd.setTabCompleter(ex);
        }
        getServer().getPluginManager().registerEvents(new CastListener(this), this);
        getServer().getPluginManager().registerEvents(menus, this);
        getServer().getScheduler().runTaskTimer(this, players::tick, 20L, 20L);
        getLogger().info("PhapBaoVIP da bat.");
    }

    @Override
    public void onDisable() {
        if (players != null) players.save();
    }

    public void reload() {
        reloadConfig();
        defs.load();
    }

    public void send(CommandSender to, String msg) {
        to.sendMessage(Msg.c(getConfig().getString("settings.prefix", "") + msg));
    }

    public void actionBar(Player p, String msg) {
        p.sendActionBar(Msg.c(msg));
    }

    public Defs defs() { return defs; }
    public Players players() { return players; }
    public ItemService items() { return items; }
    public SkillEngine engine() { return engine; }
    public Actions actions() { return actions; }
    public Menus menus() { return menus; }
}
