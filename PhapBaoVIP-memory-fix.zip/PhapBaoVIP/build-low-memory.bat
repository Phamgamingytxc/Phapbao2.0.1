@echo off
title Build PhapBaoVIP - low memory
cd /d "%~dp0"

echo [1/3] Checking Java and Maven...
java -version
if errorlevel 1 (
  echo ERROR: Java not found. Install JDK 21 and check JAVA_HOME/PATH.
  pause
  exit /b 1
)
mvn -version
if errorlevel 1 (
  echo ERROR: Maven not found or JAVA_HOME is incorrect.
  pause
  exit /b 1
)

echo.
echo [2/3] Setting conservative Maven memory options...
set "MAVEN_OPTS=-Xms128m -Xmx512m -XX:MaxMetaspaceSize=192m"

echo.
echo [3/3] Building plugin...
call mvn clean package
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  echo If Java still reports insufficient memory, close other apps and increase Windows virtual memory.
  echo See README.md for instructions.
  pause
  exit /b 1
)

echo.
echo BUILD SUCCESS. Check the target folder for PhapBaoVIP-1.0.0.jar
pause
