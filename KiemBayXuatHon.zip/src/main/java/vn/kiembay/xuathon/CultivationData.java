package vn.kiembay.xuathon;

import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Cảnh giới + linh lực của người chơi. */
public class CultivationData {
    private final KiemBayXuatHon plugin;
    private final NamespacedKey realmKey;
    private final NamespacedKey manaKey;
    private final Map<UUID, Double> mana = new HashMap<>();

    public CultivationData(KiemBayXuatHon plugin) {
        this.plugin = plugin;
        this.realmKey = new NamespacedKey(plugin, "canh_gioi");
        this.manaKey = new NamespacedKey(plugin, "linh_luc");
    }

    public int maxRealm() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("realms");
        int max = 0;
        if (s != null) {
            for (String k : s.getKeys(false)) {
                try {
                    max = Math.max(max, Integer.parseInt(k));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return max;
    }

    public int getRealm(Player p) {
        Integer v = p.getPersistentDataContainer().get(realmKey, PersistentDataType.INTEGER);
        int r = v != null ? v : plugin.getConfig().getInt("default-realm", 0);
        return Math.max(0, Math.min(r, maxRealm()));
    }

    public void setRealm(Player p, int realm) {
        p.getPersistentDataContainer().set(realmKey, PersistentDataType.INTEGER,
                Math.max(0, Math.min(realm, maxRealm())));
        addMana(p, 0); // kẹp lại theo mức tối đa mới
    }

    private ConfigurationSection section(int realm) {
        for (int r = realm; r >= 0; r--) {
            ConfigurationSection s = plugin.getConfig().getConfigurationSection("realms." + r);
            if (s != null) return s;
        }
        return null;
    }

    public String realmName(int realm) {
        ConfigurationSection s = section(realm);
        return s == null ? "Phàm Nhân" : s.getString("name", "Cảnh giới " + realm);
    }

    private double val(Player p, String key, double def) {
        ConfigurationSection s = section(getRealm(p));
        return s == null ? def : s.getDouble(key, def);
    }

    public double maxMana(Player p) {
        return val(p, "max-linh-luc", 50);
    }

    public float flySpeed(Player p) {
        double v = val(p, "fly-speed", 0.1);
        if (v <= 0) v = 0.1;
        return (float) Math.min(v, 1.0);
    }

    public double soulRange(Player p) {
        return val(p, "soul-range", 0);
    }

    public int soulSeconds(Player p) {
        return (int) val(p, "soul-seconds", 0);
    }

    public double thanThucRadius(Player p) {
        return val(p, "thanthuc-radius", 0);
    }

    // ---- linh lực ----
    public double getMana(Player p) {
        return mana.computeIfAbsent(p.getUniqueId(), k -> {
            Double saved = p.getPersistentDataContainer().get(manaKey, PersistentDataType.DOUBLE);
            return saved != null ? Math.min(saved, maxMana(p)) : maxMana(p);
        });
    }

    public void addMana(Player p, double amount) {
        double m = Math.max(0, Math.min(maxMana(p), getMana(p) + amount));
        mana.put(p.getUniqueId(), m);
    }

    public boolean consume(Player p, double amount) {
        if (amount <= 0) return true;
        double m = getMana(p);
        if (m < amount) return false;
        mana.put(p.getUniqueId(), m - amount);
        return true;
    }

    public void regen(Player p) {
        addMana(p, plugin.getConfig().getDouble("linh-luc.regen-per-second", 2.0));
    }

    public void save(Player p) {
        Double m = mana.remove(p.getUniqueId());
        if (m != null) {
            p.getPersistentDataContainer().set(manaKey, PersistentDataType.DOUBLE, m);
        }
    }
}
