package vn.kiembay.xuathon;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Ngự kiếm phi hành: bay trên một thanh kiếm (ItemDisplay) tốn linh lực. */
public class SwordFlight {
    private final KiemBayXuatHon plugin;
    private final Map<UUID, ItemDisplay> displays = new HashMap<>();
    private final Map<UUID, Boolean> hadAllowFlight = new HashMap<>();
    private final Map<UUID, Long> startedAt = new HashMap<>();
    private final Map<UUID, Long> noFallUntil = new HashMap<>();

    public SwordFlight(KiemBayXuatHon plugin) {
        this.plugin = plugin;
    }

    public boolean isFlying(Player p) {
        return displays.containsKey(p.getUniqueId());
    }

    public boolean hasFallProtection(Player p) {
        Long until = noFallUntil.get(p.getUniqueId());
        return until != null && until > System.currentTimeMillis();
    }

    public void toggle(Player p) {
        if (isFlying(p)) stop(p, "&7Ngươi thu kiếm, hạ xuống.");
        else start(p);
    }

    public void start(Player p) {
        CultivationData d = plugin.data();
        int min = plugin.getConfig().getInt("ngukiem.min-realm", 2);
        if (d.getRealm(p) < min) {
            plugin.msg(p, "&cCảnh giới chưa đủ! Cần đạt &e" + d.realmName(min) + "&c mới ngự kiếm được.");
            return;
        }
        if (p.getGameMode() == GameMode.SPECTATOR) return;
        if (plugin.soul().isSoul(p)) {
            plugin.msg(p, "&cThần hồn đang xuất khiếu, không thể ngự kiếm.");
            return;
        }
        if (!d.consume(p, plugin.getConfig().getDouble("ngukiem.mana-start", 10))) {
            plugin.msg(p, "&cLinh lực không đủ để ngự kiếm!");
            return;
        }

        UUID id = p.getUniqueId();
        hadAllowFlight.put(id, p.getAllowFlight());
        startedAt.put(id, System.currentTimeMillis());
        p.setAllowFlight(true);
        p.setFlySpeed(d.flySpeed(p));
        p.setFlying(true);
        p.setVelocity(new Vector(0, 0.45, 0));

        Material mat = Material.matchMaterial(plugin.getConfig().getString("ngukiem.sword-material", "IRON_SWORD"));
        if (mat == null) mat = Material.IRON_SWORD;
        final Material swordMat = mat;

        // Kiếm nằm ngang, mũi hướng về phía trước.
        Quaternionf rot = new Quaternionf()
                .rotateZ((float) Math.toRadians(90))
                .rotateY((float) Math.toRadians(-90))
                .rotateZ((float) Math.toRadians(-45));

        ItemDisplay disp = p.getWorld().spawn(p.getLocation(), ItemDisplay.class, e -> {
            e.setItemStack(new ItemStack(swordMat));
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            e.setTransformation(new Transformation(
                    new Vector3f(0, 0, 0), rot, new Vector3f(1.7f, 1.7f, 1.7f), new Quaternionf()));
            e.setBillboard(Display.Billboard.FIXED);
            e.setTeleportDuration(2);
            e.setPersistent(false);
            e.setInvulnerable(true);
        });
        displays.put(id, disp);
        plugin.msg(p, "&b⚔ Ngự kiếm! &7Gõ lại lệnh hoặc chuột phải Phi Kiếm để hạ xuống.");
    }

    public void stop(Player p, String reason) {
        UUID id = p.getUniqueId();
        boolean was = cleanup(id);
        if (!was) return;
        Boolean had = hadAllowFlight.remove(id);
        if (p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) {
            p.setFlying(false);
            p.setAllowFlight(had != null && had);
        }
        p.setFlySpeed(0.1f);
        long secs = plugin.getConfig().getLong("ngukiem.fall-protect-seconds", 5);
        noFallUntil.put(id, System.currentTimeMillis() + secs * 1000L);
        if (reason != null) plugin.msg(p, reason);
    }

    /** Dọn display + trạng thái; trả về true nếu đang ngự kiếm. */
    private boolean cleanup(UUID id) {
        ItemDisplay disp = displays.remove(id);
        startedAt.remove(id);
        if (disp != null) disp.remove();
        return disp != null;
    }

    public void stopAll() {
        for (UUID id : new ArrayList<>(displays.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) stop(p, null);
            else cleanup(id);
        }
    }

    /** Mỗi tick: đưa thanh kiếm theo chân người chơi. */
    public void tickMove() {
        for (UUID id : new ArrayList<>(displays.keySet())) {
            Player p = Bukkit.getPlayer(id);
            ItemDisplay disp = displays.get(id);
            if (p == null || disp == null || !disp.isValid()) {
                if (p != null) stop(p, null);
                else cleanup(id);
                continue;
            }
            Location l = p.getLocation();
            l.setPitch(0);
            l.add(0, 0.02, 0);
            disp.teleport(l);
        }
    }

    /** Mỗi giây: trừ linh lực, kiểm tra điều kiện. */
    public void tickSecond() {
        long now = System.currentTimeMillis();
        double cost = plugin.getConfig().getDouble("ngukiem.mana-per-second", 3);
        for (UUID id : new ArrayList<>(displays.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                cleanup(id);
                continue;
            }
            if (p.getGameMode() == GameMode.SPECTATOR) {
                stop(p, null);
                continue;
            }
            if (!plugin.data().consume(p, cost)) {
                stop(p, "&cLinh lực cạn kiệt, phi kiếm mất lực!");
                continue;
            }
            Long st = startedAt.get(id);
            if (!p.isFlying() && p.isOnGround() && st != null && now - st > 1500) {
                stop(p, "&7Ngươi đáp xuống đất.");
                continue;
            }
            p.sendActionBar(plugin.c("&b⚔ Ngự kiếm &7| &fLinh lực: &b"
                    + (int) plugin.data().getMana(p) + "&7/&b" + (int) plugin.data().maxMana(p)));
        }
    }
}
