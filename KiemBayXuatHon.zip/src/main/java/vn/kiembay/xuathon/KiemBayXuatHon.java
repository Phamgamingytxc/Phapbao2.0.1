package vn.kiembay.xuathon;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class KiemBayXuatHon extends JavaPlugin implements Listener, TabExecutor {
    private CultivationData data;
    private SwordFlight flight;
    private SoulProjection soul;
    private NamespacedKey swordKey;
    private final Map<UUID, Long> thanThucCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        swordKey = new NamespacedKey(this, "phi_kiem");
        data = new CultivationData(this);
        flight = new SwordFlight(this);
        soul = new SoulProjection(this);

        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("ngukiem", "xuathon", "thanthuc", "linhluc", "canhgioi", "kbxh")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(this);
                pc.setTabCompleter(this);
            }
        }

        Bukkit.getScheduler().runTaskTimer(this, flight::tickMove, 1L, 1L);
        Bukkit.getScheduler().runTaskTimer(this, soul::tickRange, 5L, 5L);
        Bukkit.getScheduler().runTaskTimer(this, this::tickSecond, 20L, 20L);

        // reload server: người đang xuất hồn từ trước được trả về nhục thân
        for (Player p : Bukkit.getOnlinePlayers()) soul.restoreAfterCrash(p);
        getLogger().info("KiemBayXuatHon da bat - Ngu kiem / Xuat hon / Than thuc");
    }

    @Override
    public void onDisable() {
        flight.stopAll();
        soul.endAll();
        for (Player p : Bukkit.getOnlinePlayers()) data.save(p);
    }

    public CultivationData data() {
        return data;
    }

    public SwordFlight flight() {
        return flight;
    }

    public SoulProjection soul() {
        return soul;
    }

    // ---------- tiện ích chat ----------
    public Component c(String legacy) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(legacy);
    }

    public void msg(CommandSender to, String legacy) {
        to.sendMessage(c(legacy));
    }

    private Component noItalic(String legacy) {
        return c(legacy).decoration(TextDecoration.ITALIC, false);
    }

    // ---------- vật phẩm Phi Kiếm ----------
    public ItemStack createSword() {
        Material m = Material.matchMaterial(getConfig().getString("ngukiem.sword-material", "IRON_SWORD"));
        if (m == null) m = Material.IRON_SWORD;
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(noItalic("&b&lPhi Kiếm"));
        meta.lore(List.of(
                noItalic("&7Chuột phải để ngự kiếm phi hành."),
                noItalic("&7Chuột phải lần nữa để hạ xuống."),
                noItalic("&8Tiêu hao linh lực.")));
        meta.getPersistentDataContainer().set(swordKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    private boolean isPhiKiem(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return it.getItemMeta().getPersistentDataContainer().has(swordKey, PersistentDataType.BYTE);
    }

    // ---------- vòng lặp mỗi giây ----------
    private void tickSecond() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!flight.isFlying(p) && !soul.isSoul(p)) data.regen(p);
        }
        flight.tickSecond();
        soul.tickSecond();
    }

    // ---------- sự kiện ----------
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isPhiKiem(e.getItem())) return;
        e.setCancelled(true);
        if (!e.getPlayer().hasPermission("kbxh.ngukiem")) return;
        flight.toggle(e.getPlayer());
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        Entity ent = e.getEntity();
        if (ent instanceof Player p) {
            if (e.getCause() == EntityDamageEvent.DamageCause.FALL && flight.hasFallProtection(p)) {
                e.setCancelled(true);
                return;
            }
            if (flight.isFlying(p) && getConfig().getBoolean("ngukiem.stop-when-hit", false)
                    && e.getCause() != EntityDamageEvent.DamageCause.FALL && e.getFinalDamage() > 0) {
                flight.stop(p, "&cBị đánh trúng, rơi khỏi phi kiếm!");
            }
        } else if (ent instanceof ArmorStand) {
            UUID owner = soul.ownerOfBody(ent);
            if (owner != null) {
                e.setCancelled(true);
                soul.bodyHit(owner, e.getDamage());
            }
        }
    }

    @EventHandler
    public void onManipulate(PlayerArmorStandManipulateEvent e) {
        if (soul.ownerOfBody(e.getRightClicked()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        if (soul.isSoul(e.getPlayer())
                && e.getCause() == PlayerTeleportEvent.TeleportCause.SPECTATE
                && getConfig().getBoolean("xuathon.block-spectate-teleport", true)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        flight.stop(p, null);
        soul.end(p, null);
        data.save(p);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) soul.restoreAfterCrash(p);
        }, 2L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        flight.stop(e.getEntity(), null);
        soul.end(e.getEntity(), null);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        flight.stop(e.getPlayer(), "&7Phi kiếm tan biến khi đổi thế giới.");
    }

    // ---------- lệnh ----------
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase()) {
            case "ngukiem" -> {
                if (!(s instanceof Player p)) return playerOnly(s);
                flight.toggle(p);
            }
            case "xuathon" -> {
                if (!(s instanceof Player p)) return playerOnly(s);
                soul.toggle(p);
            }
            case "thanthuc" -> {
                if (!(s instanceof Player p)) return playerOnly(s);
                doThanThuc(p);
            }
            case "linhluc" -> {
                if (!(s instanceof Player p)) return playerOnly(s);
                msg(p, "&bCảnh giới: &f" + data.realmName(data.getRealm(p))
                        + " &7| &bLinh lực: &f" + (int) data.getMana(p) + "&7/&f" + (int) data.maxMana(p));
            }
            case "canhgioi" -> doCanhGioi(s, args);
            case "kbxh" -> doAdmin(s, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private boolean playerOnly(CommandSender s) {
        msg(s, "&cLệnh này chỉ dùng trong game.");
        return true;
    }

    private void doThanThuc(Player p) {
        int min = getConfig().getInt("thanthuc.min-realm", 3);
        if (data.getRealm(p) < min) {
            msg(p, "&cCảnh giới chưa đủ! Cần đạt &e" + data.realmName(min) + "&c mới dùng được thần thức.");
            return;
        }
        long now = System.currentTimeMillis();
        Long cd = thanThucCooldown.get(p.getUniqueId());
        if (cd != null && cd > now) {
            msg(p, "&cThần thức đang hồi phục, chờ &e" + ((cd - now) / 1000 + 1) + "s&c.");
            return;
        }
        boolean inSoul = soul.isSoul(p);
        double radius = inSoul ? soul.rangeOf(p) : data.thanThucRadius(p);
        if (radius <= 0) {
            msg(p, "&cCảnh giới hiện tại chưa mở thần thức.");
            return;
        }
        if (!inSoul && !data.consume(p, getConfig().getDouble("thanthuc.mana-cost", 8))) {
            msg(p, "&cLinh lực không đủ để phóng thần thức!");
            return;
        }
        long cdSec = getConfig().getLong("thanthuc.cooldown-seconds", 10);
        thanThucCooldown.put(p.getUniqueId(), now + cdSec * 1000L);
        ThanThuc.report(this, p, radius);
    }

    private void doCanhGioi(CommandSender s, String[] args) {
        if (args.length >= 3 && args[0].equalsIgnoreCase("set")) {
            if (!s.hasPermission("kbxh.admin")) {
                msg(s, "&cKhông đủ quyền.");
                return;
            }
            Player t = Bukkit.getPlayerExact(args[1]);
            if (t == null) {
                msg(s, "&cKhông tìm thấy người chơi.");
                return;
            }
            try {
                data.setRealm(t, Integer.parseInt(args[2]));
            } catch (NumberFormatException ex) {
                msg(s, "&cSố cảnh giới không hợp lệ.");
                return;
            }
            msg(s, "&aĐã đặt cảnh giới của &f" + t.getName() + " &athành &e" + data.realmName(data.getRealm(t)));
            msg(t, "&bCảnh giới của ngươi nay là &e" + data.realmName(data.getRealm(t)));
            return;
        }
        if (s instanceof Player p) {
            msg(p, "&bCảnh giới hiện tại: &e" + data.realmName(data.getRealm(p)));
        }
        StringBuilder sb = new StringBuilder("&7Các cảnh giới: ");
        for (int i = 0; i <= data.maxRealm(); i++) {
            sb.append("&f").append(i).append("&7=").append(data.realmName(i)).append(i < data.maxRealm() ? ", " : "");
        }
        msg(s, sb.toString());
        if (s.hasPermission("kbxh.admin")) msg(s, "&8Admin: /canhgioi set <tên> <số>");
    }

    private void doAdmin(CommandSender s, String[] args) {
        if (args.length == 0) {
            msg(s, "&e/kbxh give [tên] &7- phát Phi Kiếm  &e/kbxh reload &7- nạp lại config");
            return;
        }
        switch (args[0].toLowerCase()) {
            case "give" -> {
                Player t = args.length >= 2 ? Bukkit.getPlayerExact(args[1]) : (s instanceof Player pl ? pl : null);
                if (t == null) {
                    msg(s, "&cKhông tìm thấy người chơi.");
                    return;
                }
                t.getInventory().addItem(createSword());
                msg(s, "&aĐã đưa Phi Kiếm cho &f" + t.getName());
            }
            case "reload" -> {
                reloadConfig();
                msg(s, "&aĐã nạp lại config.");
            }
            default -> msg(s, "&cLệnh không hợp lệ.");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase();
        if (name.equals("kbxh")) {
            if (args.length == 1) out.addAll(List.of("give", "reload"));
            else if (args.length == 2 && args[0].equalsIgnoreCase("give")) addPlayers(out);
        } else if (name.equals("canhgioi")) {
            if (args.length == 1 && s.hasPermission("kbxh.admin")) out.add("set");
            else if (args.length == 2 && args[0].equalsIgnoreCase("set")) addPlayers(out);
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase();
        out.removeIf(x -> !x.toLowerCase().startsWith(last));
        return out;
    }

    private void addPlayers(List<String> out) {
        for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
    }
}
