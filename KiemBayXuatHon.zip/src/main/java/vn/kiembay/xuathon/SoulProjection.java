package vn.kiembay.xuathon;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Xuất hồn: thần hồn rời nhục thân (spectator), nhục thân là ArmorStand đứng yên. */
public class SoulProjection {
    private static final class State {
        final Location body;
        final UUID stand;
        final GameMode gm;
        final double range;
        int secondsLeft;

        State(Location body, UUID stand, GameMode gm, double range, int secondsLeft) {
            this.body = body;
            this.stand = stand;
            this.gm = gm;
            this.range = range;
            this.secondsLeft = secondsLeft;
        }
    }

    private final KiemBayXuatHon plugin;
    private final Map<UUID, State> souls = new HashMap<>();
    private final Map<UUID, Long> cooldownUntil = new HashMap<>();
    private final NamespacedKey ownerKey;
    private final NamespacedKey gmKey;
    private final NamespacedKey bodyKey;
    private final NamespacedKey standKey;

    public SoulProjection(KiemBayXuatHon plugin) {
        this.plugin = plugin;
        this.ownerKey = new NamespacedKey(plugin, "than_xac_chu");
        this.gmKey = new NamespacedKey(plugin, "soul_gm");
        this.bodyKey = new NamespacedKey(plugin, "soul_body");
        this.standKey = new NamespacedKey(plugin, "soul_stand");
    }

    public boolean isSoul(Player p) {
        return souls.containsKey(p.getUniqueId());
    }

    public double rangeOf(Player p) {
        State s = souls.get(p.getUniqueId());
        return s == null ? 0 : s.range;
    }

    /** Nếu entity là nhục thân của ai đó thì trả về UUID chủ. */
    public UUID ownerOfBody(Entity e) {
        if (!(e instanceof ArmorStand)) return null;
        String s = e.getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (s == null) return null;
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    public void toggle(Player p) {
        if (isSoul(p)) end(p, "&bThần hồn quy vị, nhập lại nhục thân.");
        else start(p);
    }

    public void start(Player p) {
        CultivationData d = plugin.data();
        int min = plugin.getConfig().getInt("xuathon.min-realm", 4);
        if (d.getRealm(p) < min) {
            plugin.msg(p, "&cCảnh giới chưa đủ! Cần đạt &e" + d.realmName(min) + "&c mới xuất hồn được.");
            return;
        }
        if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) {
            plugin.msg(p, "&cChỉ xuất hồn được ở chế độ sinh tồn / phiêu lưu.");
            return;
        }
        if (plugin.flight().isFlying(p)) {
            plugin.msg(p, "&cHãy thu kiếm hạ xuống trước khi xuất hồn.");
            return;
        }
        double range = d.soulRange(p);
        int seconds = d.soulSeconds(p);
        if (range <= 0 || seconds <= 0) {
            plugin.msg(p, "&cCảnh giới hiện tại chưa thể xuất hồn.");
            return;
        }
        long now = System.currentTimeMillis();
        Long cd = cooldownUntil.get(p.getUniqueId());
        if (cd != null && cd > now) {
            plugin.msg(p, "&cThần hồn còn yếu, chờ &e" + ((cd - now) / 1000 + 1) + "s &cnữa.");
            return;
        }
        if (!d.consume(p, plugin.getConfig().getDouble("xuathon.mana-start", 30))) {
            plugin.msg(p, "&cLinh lực không đủ để xuất hồn!");
            return;
        }

        Location body = p.getLocation().clone();
        body.getChunk().addPluginChunkTicket(plugin);

        ArmorStand stand = body.getWorld().spawn(body, ArmorStand.class, s -> {
            s.setArms(true);
            s.setBasePlate(false);
            s.setPersistent(false);
            s.setCanPickupItems(false);
            s.customName(plugin.c("&7Nhục thân của &f" + p.getName()));
            s.setCustomNameVisible(true);
            s.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, p.getUniqueId().toString());
            EntityEquipment eq = s.getEquipment();
            if (eq != null) {
                ItemStack head = new ItemStack(Material.PLAYER_HEAD);
                if (head.getItemMeta() instanceof SkullMeta sm) {
                    sm.setOwningPlayer(p);
                    head.setItemMeta(sm);
                }
                eq.setHelmet(head);
                eq.setChestplate(clone(p.getInventory().getChestplate()));
                eq.setLeggings(clone(p.getInventory().getLeggings()));
                eq.setBoots(clone(p.getInventory().getBoots()));
                eq.setItemInMainHand(clone(p.getInventory().getItemInMainHand()));
            }
        });

        State st = new State(body, stand.getUniqueId(), p.getGameMode(), range, seconds);
        souls.put(p.getUniqueId(), st);

        // lưu để khôi phục nếu server sập
        var pdc = p.getPersistentDataContainer();
        pdc.set(gmKey, PersistentDataType.STRING, st.gm.name());
        pdc.set(bodyKey, PersistentDataType.STRING, ser(body));
        pdc.set(standKey, PersistentDataType.STRING, stand.getUniqueId().toString());

        p.setGameMode(GameMode.SPECTATOR);
        if (plugin.getConfig().getBoolean("xuathon.night-vision", true)) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, seconds * 20 + 40, 0, false, false, false));
        }
        plugin.msg(p, "&b✦ Xuất hồn! &7Tầm tối đa &f" + (int) range + "m&7, duy trì &f" + seconds
                + "s&7. Nhục thân bị đánh thì thần hồn bị kéo về. Gõ &f/xuathon &7để nhập thể.");
    }

    public void end(Player p, String reason) {
        State st = souls.remove(p.getUniqueId());
        if (st == null) return;
        p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        p.setGameMode(st.gm);
        p.teleport(st.body, PlayerTeleportEvent.TeleportCause.PLUGIN);
        Entity stand = Bukkit.getEntity(st.stand);
        if (stand != null) stand.remove();
        st.body.getChunk().removePluginChunkTicket(plugin);
        clearPdc(p);

        long cd = plugin.getConfig().getLong("xuathon.cooldown-seconds", 90);
        cooldownUntil.put(p.getUniqueId(), System.currentTimeMillis() + cd * 1000L);
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1, false, true, true));
        if (reason != null) plugin.msg(p, reason);
    }

    public void endAll() {
        for (UUID id : new ArrayList<>(souls.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) end(p, null);
        }
    }

    /** Nhục thân bị tấn công: kéo hồn về rồi chịu sát thương. */
    public void bodyHit(UUID owner, double damage) {
        Player p = Bukkit.getPlayer(owner);
        if (p == null || !isSoul(p)) return;
        end(p, "&cNhục thân bị tấn công! Thần hồn bị kéo về, phản phệ!");
        if (damage > 0) p.damage(damage);
    }

    /** Mỗi 5 tick: giữ thần hồn trong tầm cho phép. */
    public void tickRange() {
        for (UUID id : new ArrayList<>(souls.keySet())) {
            Player p = Bukkit.getPlayer(id);
            State st = souls.get(id);
            if (p == null || st == null) continue;
            Location l = p.getLocation();
            if (!l.getWorld().equals(st.body.getWorld()) || l.distanceSquared(st.body) > st.range * st.range) {
                Location back = st.body.clone();
                back.setYaw(l.getYaw());
                back.setPitch(l.getPitch());
                p.teleport(back, PlayerTeleportEvent.TeleportCause.PLUGIN);
                p.sendActionBar(plugin.c("&cThần hồn không thể rời nhục thân quá xa!"));
            }
        }
    }

    /** Mỗi giây: đếm giờ, trừ linh lực, quét thần thức. */
    public void tickSecond() {
        double cost = plugin.getConfig().getDouble("xuathon.mana-per-second", 1.5);
        for (UUID id : new ArrayList<>(souls.keySet())) {
            Player p = Bukkit.getPlayer(id);
            State st = souls.get(id);
            if (p == null || st == null) continue;
            st.secondsLeft--;
            if (st.secondsLeft <= 0) {
                end(p, "&7Hết thời gian xuất hồn, thần hồn quy vị.");
            } else if (!plugin.data().consume(p, cost)) {
                end(p, "&cLinh lực cạn kiệt, thần hồn bị kéo về!");
            } else {
                p.sendActionBar(ThanThuc.brief(plugin, p, st.range, st.secondsLeft));
            }
        }
    }

    /** Server sập / reload lúc đang xuất hồn: trả người chơi về nhục thân. */
    public void restoreAfterCrash(Player p) {
        var pdc = p.getPersistentDataContainer();
        String body = pdc.get(bodyKey, PersistentDataType.STRING);
        if (body == null || isSoul(p)) return;
        String gm = pdc.get(gmKey, PersistentDataType.STRING);
        String standId = pdc.get(standKey, PersistentDataType.STRING);
        Location loc = de(body);
        GameMode mode = GameMode.SURVIVAL;
        try {
            if (gm != null) mode = GameMode.valueOf(gm);
        } catch (IllegalArgumentException ignored) {
        }
        p.setGameMode(mode);
        if (loc != null) p.teleport(loc, PlayerTeleportEvent.TeleportCause.PLUGIN);
        if (standId != null) {
            try {
                Entity e = Bukkit.getEntity(UUID.fromString(standId));
                if (e != null) e.remove();
            } catch (IllegalArgumentException ignored) {
            }
        }
        clearPdc(p);
        plugin.msg(p, "&7Thần hồn đã được đưa về nhục thân.");
    }

    private void clearPdc(Player p) {
        var pdc = p.getPersistentDataContainer();
        pdc.remove(gmKey);
        pdc.remove(bodyKey);
        pdc.remove(standKey);
    }

    private static ItemStack clone(ItemStack it) {
        return it == null ? null : it.clone();
    }

    private static String ser(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ()
                + ";" + l.getYaw() + ";" + l.getPitch();
    }

    private static Location de(String s) {
        try {
            String[] a = s.split(";");
            World w = Bukkit.getWorld(a[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(a[1]), Double.parseDouble(a[2]),
                    Double.parseDouble(a[3]), Float.parseFloat(a[4]), Float.parseFloat(a[5]));
        } catch (RuntimeException e) {
            return null;
        }
    }
}
