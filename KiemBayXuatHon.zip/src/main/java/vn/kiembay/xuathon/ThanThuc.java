package vn.kiembay.xuathon;

import net.kyori.adventure.text.Component;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Thần thức: quét người / quái / thú xung quanh. */
public final class ThanThuc {
    private static final String[] DIRS = {"Bắc", "Đông Bắc", "Đông", "Đông Nam", "Nam", "Tây Nam", "Tây", "Tây Bắc"};

    private ThanThuc() {
    }

    public static final class Result {
        final List<Player> players = new ArrayList<>();
        int monsters;
        int animals;
    }

    public static Result scan(Player self, double radius) {
        Result r = new Result();
        Location c = self.getLocation();
        double r2 = radius * radius;
        for (Entity e : c.getWorld().getNearbyEntities(c, radius, radius, radius)) {
            if (e.equals(self) || e.getLocation().distanceSquared(c) > r2) continue;
            if (e instanceof Player o) {
                if (o.getGameMode() == GameMode.SPECTATOR) continue;
                if (!self.canSee(o) || o.hasPermission("kbxh.hide")) continue;
                r.players.add(o);
            } else if (e instanceof Monster) {
                r.monsters++;
            } else if (e instanceof Animals) {
                r.animals++;
            }
        }
        r.players.sort(Comparator.comparingDouble(o -> o.getLocation().distanceSquared(c)));
        return r;
    }

    public static String direction(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double ang = Math.toDegrees(Math.atan2(dx, -dz));
        if (ang < 0) ang += 360;
        return DIRS[(int) Math.round(ang / 45.0) % 8];
    }

    /** Gửi bảng kết quả đầy đủ vào chat. */
    public static void report(KiemBayXuatHon plugin, Player p, double radius) {
        Result r = scan(p, radius);
        Location c = p.getLocation();
        plugin.msg(p, "&b✦ Thần thức &7(bán kính &f" + (int) radius + "m&7)");
        if (r.players.isEmpty()) {
            plugin.msg(p, "&7  Không phát hiện tu sĩ nào.");
        } else {
            int shown = 0;
            for (Player o : r.players) {
                if (shown++ >= 8) {
                    plugin.msg(p, "&7  ... và " + (r.players.size() - 8) + " người nữa");
                    break;
                }
                Location ol = o.getLocation();
                double dist = Math.sqrt(ol.distanceSquared(c));
                double dy = ol.getY() - c.getY();
                String h = Math.abs(dy) < 8 ? "" : (dy > 0 ? ", cao hơn" : ", thấp hơn");
                plugin.msg(p, "&e  - " + o.getName() + " &7(" + (int) dist + "m, hướng " + direction(c, ol) + h + ")");
            }
        }
        plugin.msg(p, "&c  Yêu thú hung hãn: &f" + r.monsters + "  &a Sinh linh hiền: &f" + r.animals);
    }

    /** Dòng tóm tắt cho action bar khi xuất hồn. */
    public static Component brief(KiemBayXuatHon plugin, Player p, double radius, int secondsLeft) {
        Result r = scan(p, radius);
        String nearest = "-";
        if (!r.players.isEmpty()) {
            Player o = r.players.get(0);
            nearest = o.getName() + " " + (int) Math.sqrt(o.getLocation().distanceSquared(p.getLocation())) + "m";
        }
        return plugin.c("&bThần hồn &7| &f" + secondsLeft + "s &7| &eNgười: &f" + r.players.size()
                + " &7| &cQuái: &f" + r.monsters + " &7| &fGần nhất: &e" + nearest);
    }
}
