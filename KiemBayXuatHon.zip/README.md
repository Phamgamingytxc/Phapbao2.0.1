# KiemBayXuatHon

Plugin Paper 1.21.11 (Java 21): **Ngự kiếm**, **Xuất hồn**, **Thần thức** theo phong cách server tu tiên.

## Cơ chế
- **Cảnh giới + linh lực**: Phàm Nhân → Đại Thừa (chỉnh trong `config.yml`). Mỗi cảnh giới có linh lực tối đa, tốc độ bay, tầm/thời gian xuất hồn, bán kính thần thức.
- **Ngự kiếm** (`/ngukiem` hoặc chuột phải **Phi Kiếm**): bay trên thanh kiếm, tốn linh lực mỗi giây, hạ xuống được miễn sát thương rơi vài giây.
- **Xuất hồn** (`/xuathon`): thần hồn bay tự do (xuyên block, nhìn đêm), nhục thân đứng lại. Giới hạn tầm + thời gian, có hồi chiêu. Nhục thân bị đánh → hồn bị kéo về và chịu phản phệ.
- **Thần thức** (`/thanthuc`): quét người chơi / quái / thú quanh bạn (tên, khoảng cách, hướng). Khi đang xuất hồn thì quét miễn phí và có thông tin tự cập nhật trên action bar.

## Lệnh
`/ngukiem` `/xuathon` `/thanthuc` `/linhluc` `/canhgioi [set <tên> <số>]` `/kbxh give|reload`

## Quyền
`kbxh.ngukiem` `kbxh.xuathon` `kbxh.thanthuc` (mặc định true), `kbxh.admin` (op), `kbxh.hide` (không bị thần thức quét thấy).

## Build
`mvn package` → `target/KiemBayXuatHon-1.0.0.jar`.
Hoặc đẩy lên GitHub: workflow `.github/workflows/build.yml` tự build. Tạo tag `v1.0.0` để jar xuất hiện ở mục **Releases**.
